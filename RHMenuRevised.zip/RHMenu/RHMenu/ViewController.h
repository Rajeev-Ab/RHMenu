//
//  ViewController.h
//  RHMenu
//
//  Created by Curiologix on 14/05/2020.
//  Copyright © 2020 Curiologix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

