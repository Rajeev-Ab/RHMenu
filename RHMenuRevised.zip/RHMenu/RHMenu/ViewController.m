//
//  ViewController.m
//  RHMenu
//
//  Created by Curiologix on 14/05/2020.
//  Copyright © 2020 Curiologix. All rights reserved.
//

#import "ViewController.h"
#import "RHMenu-Swift.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self  configureExpandingMenuButton];
  
}

-(void)showAlertWihTile:(NSString*)title {
    UIAlertController* alertController =  [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alertController addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alertController animated:true completion:nil];
}
-(void)configureExpandingMenuButton{
         
     ExpandingMenuButton* menuButton = [[ExpandingMenuButton alloc] initWithFrame:CGRectMake(0, 0, 64, 64) image:[UIImage imageNamed:@"chooser-button-tab"] highlightedImage:nil rotatedImage:[UIImage imageNamed:@"chooser-button-tab-highlighted"] rotatedHighlightedImage:nil];
    CGRect bounds = [self.view bounds];
    CGFloat xPosition = bounds.size.width - 32.0;
     CGFloat yPosition = bounds.size.height - 72.0;
    menuButton.center = CGPointMake(xPosition, yPosition);
    [self.view addSubview:menuButton];
   // CGSize menuButtonSize = CGSizeMake(64.0, 64.0);
    
    ExpandingMenuItem* item1 = [[ExpandingMenuItem alloc] initWithTitle:@"Music" titleColor:nil image:[UIImage imageNamed: @"chooser-moment-icon-music"] highlightedImage:[UIImage imageNamed: @"chooser-moment-icon-place-highlighted"] backgroundImage:[UIImage imageNamed: @"chooser-moment-button"] backgroundHighlightedImage:[UIImage imageNamed: @"chooser-moment-button-highlighted"] itemTapped:^{
        [self showAlertWihTile:@"Music"];
    }];

    
    ExpandingMenuItem* item2 = [[ExpandingMenuItem alloc] initWithTitle:@"Place" titleColor:nil image:[UIImage imageNamed: @"chooser-moment-icon-place"] highlightedImage:[UIImage imageNamed: @"chooser-moment-icon-place-highlighted"] backgroundImage:[UIImage imageNamed: @"chooser-moment-button"] backgroundHighlightedImage:[UIImage imageNamed: @"chooser-moment-button-highlighted"] itemTapped:^{
        [self showAlertWihTile:@"Place"];
    }];
    
    ExpandingMenuItem* item3 = [[ExpandingMenuItem alloc] initWithTitle:@"Camera" titleColor:nil image:[UIImage imageNamed: @"chooser-moment-icon-camera"] highlightedImage:[UIImage imageNamed: @"chooser-moment-icon-camera-highlighted"] backgroundImage:[UIImage imageNamed: @"chooser-moment-button"] backgroundHighlightedImage:[UIImage imageNamed: @"chooser-moment-button-highlighted"] itemTapped:^{
        [self showAlertWihTile:@"Music"];
    }];
    
    
    ExpandingMenuItem* item4 = [[ExpandingMenuItem alloc] initWithTitle:@"Thought" titleColor:nil image:[UIImage imageNamed: @"chooser-moment-icon-sleep"] highlightedImage:[UIImage imageNamed: @"chooser-moment-icon-sleep-highlighted"] backgroundImage:[UIImage imageNamed: @"chooser-moment-button"] backgroundHighlightedImage:[UIImage imageNamed: @"chooser-moment-button-highlighted"] itemTapped:^{
        [self showAlertWihTile:@"Sleep"];
    }];
    
    
    NSArray* items = [NSArray arrayWithObjects:item1,item2,item3,item4, nil];
    
    [menuButton addMenuItems:items];
    
    [menuButton setWillPresentMenuItems:^(ExpandingMenuButton * menu) {
        NSLog(@"MenuItems will present.");
    }];
    
    [menuButton setDidDismissMenuItems:^(ExpandingMenuButton * menu) {
         NSLog(@"MenuItems dismissed.");
    }];
   
}



@end
